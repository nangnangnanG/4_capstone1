from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # Django Admin
    
    # API URL 패턴들
    path('api/users/', include('users.urls')),  # 사용자 API
    path('api/feeds/', include('feeds.urls')),  # 피드 API
    path('api/artifacts/', include('artifacts.urls')),  # 유물 API
    path('api/models/', include('model3d.urls')),  # 3D 모델 API
]

# 미디어 파일 제공 (DEBUG=True일 때만 적용됨)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)