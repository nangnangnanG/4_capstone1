# artifacts/serializers.py
from rest_framework import serializers
from .models import Artifact, ArtifactFeed
from feeds.models import Feed
from feeds.serializers import FeedSerializer, UserMinimalSerializer

class ArtifactSerializer(serializers.ModelSerializer):
    """유물 정보 시리얼라이저"""
    feed_count = serializers.SerializerMethodField()
    has_3d_model = serializers.SerializerMethodField()
    
    class Meta:
        model = Artifact
        fields = [
            'id', 'name', 'description', 'time_period', 'estimated_year',
            'origin_location', 'status', 'image_count', 'feed_count',
            'has_3d_model', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'image_count', 'created_at', 'updated_at']
    
    def get_feed_count(self, obj):
        """연관된 피드 수를 반환"""
        return obj.artifact_feeds.count()
    
    def get_has_3d_model(self, obj):
        """3D 모델 존재 여부를 반환"""
        return obj.models.filter(status='completed').exists()

class ArtifactDetailSerializer(ArtifactSerializer):
    """유물 상세 정보 시리얼라이저"""
    feeds = serializers.SerializerMethodField()
    
    class Meta(ArtifactSerializer.Meta):
        fields = ArtifactSerializer.Meta.fields + ['feeds']
    
    def get_feeds(self, obj):
        """연관된 피드 목록을 반환 (최대 5개)"""
        artifact_feeds = ArtifactFeed.objects.filter(artifact=obj).select_related('feed')[:5]
        feeds = [item.feed for item in artifact_feeds]
        return FeedSerializer(feeds, many=True).data