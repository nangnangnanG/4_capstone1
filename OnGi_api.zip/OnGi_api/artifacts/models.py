from django.db import models
import uuid
from feeds.models import Feed
from users.models import User


class Artifact(models.Model):
    """
    시스템에 등록된 유물 정보를 저장하는 모델
    같은 유물 이름으로 피드 이미지 10장 이상 모이면 자동 생성됨
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    time_period = models.CharField(max_length=100, blank=True, null=True)  # 시대
    estimated_year = models.CharField(max_length=100, blank=True, null=True)  # 추정 연도
    origin_location = models.CharField(max_length=200, blank=True, null=True)  # 출토 위치
    
    STATUS_CHOICES = [
        ('auto_generated', '자동 생성됨'),
        ('verified', '검증됨'),
        ('featured', '주목할 만한'),
        ('rejected', '거부됨'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='auto_generated')
    
    image_count = models.IntegerField(default=0)  # 현재까지 수집된 이미지 수
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'artifacts'


class ArtifactFeed(models.Model):
    """
    유물과 관련 피드 간의 연결을 저장하는 모델
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    artifact = models.ForeignKey(Artifact, on_delete=models.CASCADE, related_name='artifact_feeds')
    feed = models.ForeignKey(Feed, on_delete=models.CASCADE, related_name='feed_artifacts')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.artifact.name} - {self.feed.title}"

    class Meta:
        db_table = 'artifact_feeds'
        unique_together = ('artifact', 'feed')  # 중복 방지


# 이 부분은 피드 모델에 추가하는 코드는 아니지만, 참고용으로 표시합니다.
# 피드 저장 후 artifact_name 기준으로 이미지 수를 확인하여 
# 10장 이상이면 Artifact 생성 및 연결하는 함수

def check_and_create_artifact(artifact_name):
    """
    특정 유물명으로 등록된 피드 이미지가 10장 이상인지 확인하고
    조건을 충족하면 Artifact 객체를 생성하는 함수
    
    이 함수는 Feed 저장 시그널 핸들러에서 호출하거나
    피드 저장 후 뷰에서 직접 호출할 수 있습니다.
    """
    from django.db.models import Count, Sum
    
    # 같은 유물명을 가진 피드들의 이미지 수를 계산
    feeds = Feed.objects.filter(artifact_name=artifact_name, status='published')
    total_images = feeds.annotate(img_count=Count('images')).aggregate(Sum('img_count'))['img_count__sum'] or 0
    
    # 이미 생성된 유물이 있는지 확인
    existing_artifact = Artifact.objects.filter(name=artifact_name).first()
    
    if total_images >= 10 and not existing_artifact:
        # 10장 이상이고 아직 유물이 생성되지 않았으면 생성
        artifact = Artifact.objects.create(
            name=artifact_name,
            image_count=total_images,
            status='auto_generated'
        )
        
        # 관련 피드들과 연결
        for feed in feeds:
            ArtifactFeed.objects.create(
                artifact=artifact,
                feed=feed
            )
            
        return artifact
    elif existing_artifact:
        # 이미 있는 경우 이미지 수 업데이트
        existing_artifact.image_count = total_images
        existing_artifact.save()
        
        # 연결되지 않은 피드가 있으면 연결
        existing_feeds = ArtifactFeed.objects.filter(artifact=existing_artifact).values_list('feed_id', flat=True)
        for feed in feeds:
            if feed.id not in existing_feeds:
                ArtifactFeed.objects.create(
                    artifact=existing_artifact,
                    feed=feed
                )
                
        return existing_artifact
    
    return None