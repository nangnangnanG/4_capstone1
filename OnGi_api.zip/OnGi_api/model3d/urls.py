# model3d/urls.py
from django.urls import path
from .views import (
    model3d_list_view,
    model3d_detail_view,
    artifact_models_view,
    create_model_request_view,
    update_model_status_view,
)

urlpatterns = [
    path('', model3d_list_view, name='model3d-list'),
    path('<uuid:model_id>/', model3d_detail_view, name='model3d-detail'),
    path('artifacts/<uuid:artifact_id>/', artifact_models_view, name='artifact-models'),
    path('artifacts/<uuid:artifact_id>/create/', create_model_request_view, name='create-model-request'),
    path('<uuid:model_id>/update-status/', update_model_status_view, name='update-model-status'),
]