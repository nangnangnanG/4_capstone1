from django.db import models
import uuid
from artifacts.models import Artifact


class Model3D(models.Model):
    """
    유물의 3D 모델 정보를 저장하는 모델
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    artifact = models.ForeignKey(Artifact, on_delete=models.CASCADE, related_name='models')
    model_url = models.TextField()  # 3D 모델 파일 경로
    thumbnail_url = models.TextField(blank=True, null=True)  # 3D 모델 썸네일 이미지
    
    FILE_FORMAT_CHOICES = [
        ('obj', 'OBJ'),
        ('glb', 'GLB'),
        ('gltf', 'GLTF'),
        ('fbx', 'FBX'),
        ('stl', 'STL'),
        ('other', '기타'),
    ]
    file_format = models.CharField(max_length=10, choices=FILE_FORMAT_CHOICES)
    
    poly_count = models.IntegerField(blank=True, null=True)  # 폴리곤 수
    file_size = models.IntegerField(blank=True, null=True)  # 파일 크기 (KB)
    
    STATUS_CHOICES = [
        ('pending', '대기 중'),
        ('processing', '처리 중'),
        ('completed', '완료'),
        ('failed', '실패'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    processing_time = models.IntegerField(blank=True, null=True)  # 처리 소요 시간(초)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"3D Model for {self.artifact.name}"

    class Meta:
        db_table = 'model3d'
        verbose_name = '3D Model'
        verbose_name_plural = '3D Models'


class ModelTexture(models.Model):
    """
    3D 모델에 사용되는 텍스처를 저장하는 모델
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    model = models.ForeignKey(Model3D, on_delete=models.CASCADE, related_name='textures')
    texture_url = models.TextField()  # 텍스처 파일 경로
    
    TEXTURE_TYPE_CHOICES = [
        ('diffuse', 'Diffuse'),
        ('normal', 'Normal'),
        ('specular', 'Specular'),
        ('roughness', 'Roughness'),
        ('metallic', 'Metallic'),
        ('ao', 'Ambient Occlusion'),
        ('emissive', 'Emissive'),
        ('other', '기타'),
    ]
    texture_type = models.CharField(max_length=20, choices=TEXTURE_TYPE_CHOICES, default='diffuse')
    
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.texture_type} texture for {self.model}"

    class Meta:
        db_table = 'model_textures'