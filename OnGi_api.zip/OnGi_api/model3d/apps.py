from django.apps import AppConfig


class Model3DConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'model3d'
