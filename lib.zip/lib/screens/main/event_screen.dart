import 'package:flutter/material.dart';

class EventScreenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
        ),
      ),
    );
  }
}